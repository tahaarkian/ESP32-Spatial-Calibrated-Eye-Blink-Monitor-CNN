#pragma once
#include "calib_solver.h"

struct EyeBox {
    int x;
    int y;
    int w;
    int h;
    bool valid;
};

struct BlinkStepResult {
    float p_closed;         // Smoothed calibrated probability
    bool is_closed;         // Debounced eye state
    int total_blinks;       // Cumulative blink count
    bool wake_fallback;     // True ONLY when uncertain (triggers esp-face re-crop)
    int fallback_frames_left;
};

class Esp32BlinkEngine {
public:
    CalibParams calib = {1.0f, 0.0f, 0.0f, 0.0f};
    EyeBox eye_box = {0, 0, 24, 24, false};
    float est_dist_cm = 50.0f;
    float est_lat_cm = 0.0f;

    void reset() {
        hist_[0] = hist_[1] = hist_[2] = 0.0f;
        hist_count_ = 0;
        closed_streak_ = 0;
        blink_counted_ = false;
        uncertain_streak_ = 0;
        fallback_timer_ = 0;
        total_blinks_ = 0;
    }

    // Call this whenever esp-face finds the face & eye landmarks (during calibration or fallback)
    void update_eye_location(int ex, int ey, int ew, int eh, float dist_cm, float lat_cm) {
        eye_box = {ex, ey, ew, eh, true};
        est_dist_cm = dist_cm;
        est_lat_cm = lat_cm;
        uncertain_streak_ = 0;
    }

    // Call every frame with raw_logit from eye_model.h
    BlinkStepResult step(float raw_logit) {
        float p_raw = predict_calibrated_prob(raw_logit, est_dist_cm, est_lat_cm, calib);

        // 1. 3-frame moving average to remove single-frame noise
        hist_[hist_count_ % 3] = p_raw;
        hist_count_++;
        int n = hist_count_ < 3 ? hist_count_ : 3;
        float p_smooth = 0.0f;
        for (int i = 0; i < n; ++i) p_smooth += hist_[i];
        p_smooth /= static_cast<float>(n);

        // 2. Confidence Gate: uncertain zone is [0.25, 0.75]
        bool uncertain = (p_smooth >= 0.25f && p_smooth <= 0.75f) || !eye_box.valid;
        if (uncertain) {
            uncertain_streak_++;
            if (uncertain_streak_ >= 2 && fallback_timer_ == 0) {
                fallback_timer_ = 30; // Wake esp-face fallback for ~30 frames (~2 seconds)
            }
        } else {
            uncertain_streak_ = 0;
        }

        bool wake_fb = false;
        if (fallback_timer_ > 0) {
            wake_fb = true;
            fallback_timer_--;
        }

        // 3. Debounced Blink Counter (requires >= 2 consecutive closed frames)
        bool is_closed = (p_smooth >= 0.50f);
        if (is_closed) {
            closed_streak_++;
            if (closed_streak_ >= 2 && !blink_counted_) {
                total_blinks_++;
                blink_counted_ = true;
            }
        } else {
            closed_streak_ = 0;
            blink_counted_ = false;
        }

        return {p_smooth, is_closed, total_blinks_, wake_fb, fallback_timer_};
    }

private:
    float hist_[3] = {0.0f, 0.0f, 0.0f};
    int hist_count_ = 0;
    int closed_streak_ = 0;
    bool blink_counted_ = false;
    int uncertain_streak_ = 0;
    int fallback_timer_ = 0;
    int total_blinks_ = 0;
};
