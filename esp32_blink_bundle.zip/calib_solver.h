#pragma once
#include <cmath>

struct CalibSample {
    float logit;
    float d_norm;
    float x_norm;
    float y_sign; // -1.0f = open, +1.0f = closed
};

struct CalibParams {
    float alpha;
    float w0;
    float w1;
    float w2;
};

inline CalibParams solve_convex_calibration_esp32(
    const CalibSample* samples,
    int n_samples,
    float l2_reg = 0.05f,
    int steps = 400,
    float lr = 0.25f
) {
    CalibParams p = {1.0f, 0.0f, 0.0f, 0.0f};
    if (n_samples <= 0) return p;
    const float inv_n = 1.0f / static_cast<float>(n_samples);

    for (int iter = 0; iter < steps; ++iter) {
        float g_alpha = 0.0f, g_w0 = 0.0f, g_w1 = 0.0f, g_w2 = 0.0f;

        for (int i = 0; i < n_samples; ++i) {
            const float z = samples[i].logit;
            const float d = samples[i].d_norm;
            const float x = samples[i].x_norm;
            const float y = samples[i].y_sign;

            const float tau = p.w0 + p.w1 * d + p.w2 * x;
            const float margin = y * (p.alpha * z - tau);

            float neg_sig;
            if (margin >= 0.0f) {
                float e = std::exp(-margin);
                neg_sig = -e / (1.0f + e);
            } else {
                float e = std::exp(margin);
                neg_sig = -1.0f / (1.0f + e);
            }

            const float coeff = neg_sig * y * inv_n;
            g_alpha += coeff * z;
            g_w0    -= coeff;
            g_w1    -= coeff * d;
            g_w2    -= coeff * x;
        }

        g_w1 += l2_reg * p.w1;
        g_w2 += l2_reg * p.w2;

        p.alpha -= lr * g_alpha;
        if (p.alpha < 0.05f) p.alpha = 0.05f;
        if (p.alpha > 20.0f) p.alpha = 20.0f;

        p.w0 -= lr * g_w0;
        p.w1 -= lr * g_w1;
        p.w2 -= lr * g_w2;
    }
    return p;
}

inline float predict_calibrated_prob(float raw_logit, float dist_cm, float lat_cm, const CalibParams& p) {
    const float d_norm = (dist_cm - 50.0f) / 25.0f;
    const float x_norm = lat_cm / 20.0f;
    const float cal_logit = p.alpha * raw_logit - (p.w0 + p.w1 * d_norm + p.w2 * x_norm);
    return 1.0f / (1.0f + std::exp(-cal_logit));
}
